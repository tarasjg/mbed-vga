/*
 * 640x400 70Hz fullgraphic monochrome VGA Driver demo program
 *
 * Copyright (C) 2011 by Ivo van Poorten <ivop(at)euronet.nl>
 * and Gert van der Knokke <gertk(at)xs4all.nl>
 * This file is licensed under the terms of the GNU Lesser
 * General Public License, version 3.
 *
 * Inspired by Simon's (not Ford) Cookbook entry and Cliff Biffle's
 * assembly code.
 */
 
#include "mbed.h"
#include "vga640x400g.h"

// visual feedback
DigitalOut myled(LED1);

// define serial port for debug
Serial linktopc(USBTX,USBRX);

int main() {
    // init the VGA subsystem (always do this first!)
    init_vga();

    int s,t;

    // serial port on at 115200 baud
    linktopc.baud(115200);
    setbuf(stdout, NULL); // no buffering for this filehandle
    
    // clear the screen
    vga_cls();
    
    // circumfence the screen
    vga_box(0,0,639,399,WHITE);
    
    
  

    // put a string on screen
 
    vga_putstring(200,200,"hello, it works, print via VGA",WHITE);
    
   // show the complete character set
    for (s=0; s<4; s++) {
        for (t=0; t<64; t++) {
            vga_putchar(20+t*8,20+16*s,t+s*64,WHITE);
        }
    }
    
    // all done
    while (1){
         wait(1);
       myled=!myled;
    }
 }
