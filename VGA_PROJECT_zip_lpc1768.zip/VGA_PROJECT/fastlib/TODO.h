/* on a "need to have" basis :)
 *
 * adc
 * can
 * dac
 * ethernet
 * external interrupts
 * i2c
 * mcpwm
 * mpu (memory protection unit)
 * quadrature encoder interface
 * repetitive interrupt timer
 * spi
 * ssp
 * system timer (systick)
 * timer
 * usb
 * watchdog timer
 *
 */