#ifndef VGA640X400_H
#define VGA640X400_H

extern unsigned char *vga_font8x16;
void vga_plot(int x,int y,char color);
void vga_putchar(int x,int y,int c,char color);
void vga_line(int x0, int y0, int x1, int y1, char color);
void vga_circle(int x0,int y0, int radius, char color);
void vga_box(int x0, int y0, int x1, int y1,char color);
void vga_putstring(int x,int y, char *s, char color);
void vga_filledbox(int x0, int y0, int x1, int y1,char color);
void vga_scroll();
void vga_cls();

#define WHITE 1
#define BLACK 0
 
// Always call this as the very first thing in your application
// as it resets the CPU clock to 100MHz. It also resets UART0
// to 9600 baud with the new clock. All other peripherals are off
// after a call to init_vga()

void init_vga(void);

#endif